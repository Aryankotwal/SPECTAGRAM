import React from "react"
import {
ScrollView,
View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Linking,
Platform,
StatusBar,
ImageBackground,
Image} from "react-native";
import HomeScreen from "./HomeScreen"
export default class OutdoorGames extends React.Component{
  OutdoorGames=async()=>{
    Linking.openURL("https://essayshout.com/outdoor-games-importance-essay/")
  }
  render(){
    return(
      <View>
      <ImageBackground source={require("../assets/Black.jpg")}style={{width: 315,height:1400}}>

      <Image source={require("../assets/CameraLogo.png")}style={{width:100,height:100,marginTop:-20}}/>

      <Text style={{fontSize:20,fontWeight:"bold",marginTop:-60,marginLeft:80,fontFamily:"cursive",color:"white"}}> Outdoor Games </Text>

     <Image source={require("../assets/image_5.jpg")}style={{width:290,height:180,marginTop:30,alignSelf:"center",borderRadius:30}} />

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 1. Outdoor Games. </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:10}}> Outdoor Games are usually free Unlike many gyms or recreational centers that host games, playing outside is usually free. You can find basketball courts, tennis courts, and more in public parks that are maintained with tax dollars. For many games, all you need is an open field. Playing outside is accessible to anyone regardless of their budget. </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 2. Outdoor Games Help Children’s Academic Performance. </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:10}}> In a 2010 National Wildlife Federation study, 78% of the teachers surveyed said children who spent time outside playing performed better in the classroom. This makes sense considering children often have a lot of energy they need to release. In 2016, a study published by Plymouth University also showed that children who go camping at least once a year have better grades. </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 3. Playing Outside Is The Best Source Of Vitamin D </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> You can take Vitamin D supplements, but sunlight remains the best natural source. Getting enough vitamin D is important. If you’re low, you’re at a higher risk of getting type 1 diabetes, certain types of cancer, and muscle pain. Vitamin D promotes the absorption of calcium, which is vital for strong bones. That doesn’t mean you should spend hours out in the sun without sunscreen. For most people, you’ll get enough Vitamin D with just 5-10 minutes in the sun 2-3 times a week. You should then put on sunscreen. </Text>

     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> And If You Want To Know More About Advantages Of Outdoor Games </Text>
     <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:10}}> Click Down Below👇👇.. </Text>

      <TouchableOpacity onPress={this.OutdoorGames}>
      <Text style={{fontWeight:"bold",color:"white",marginLeft:20,marginTop:20,fontFamily:"cursive"}}> 1. Outdoor Games </Text>
      <Image source={require("../assets/cricket.jpg")}style={{width:290,height:180,marginTop:10, alignSelf:"center",borderRadius:30}} />
      </TouchableOpacity>
      </ImageBackground>
      </View>
    )
  }
}