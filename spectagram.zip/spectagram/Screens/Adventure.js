import React from "react"
import {
ScrollView,
View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Linking,
Platform,
StatusBar,
ImageBackground,
Image} from "react-native";
export default class Adventure extends React.Component{
  Adventure=async()=>{
    Linking.openURL("https://tourismnotes.com/adventure-tourism/")
  }
  render(){
    return(
      <View>
     <ImageBackground source={require("../assets/Black.jpg")} style={{width: 315,height:1600}}>
      <Image source={require("../assets/CameraLogo.png")}style={{width:100,height:100,marginTop:-20}}/>
      <Text style={{fontSize:20,fontWeight:"bold",marginTop:-60,marginLeft:80,fontFamily:"cursive",color:"white"}}> Adventure Campsite </Text>
     <Image source={require("../assets/image_7.jpg")}style={{width:290,height:180,marginTop:30,alignSelf:"center",borderRadius:30}} /> 
     <Text style={{color:"orange",fontWeight:"bold",fontSize:20,marginLeft:10,marginTop:20}}> 10 Reasons Why Children Must Attend An Outdoor Adventure Camp </Text>
     <Text style={{color:"white",fontWeight:"bold",marginLeft:10,marginTop:20}}> 1. Going on an outdoor Adventure Camp is a real treat for kids! It’s a great opportunity to enable children with the skills and knowledge they need in order to explore, play and learn outdoors. Adventure Camps provide activities which are ideal for fostering physical development, building confidence and self-esteem, as well as honing problem-solving abilities. </Text>

      <Text style={{color:"white",fontWeight:"bold",marginLeft:10,marginTop:20}}> 2. The excitement and happiness we experience during an adventure release hormones that are great for our mental health. Moreover, surmounting a challenge during an adventure is a brilliant way to leave us feeling positive about ourselves. Adventures give us a more positive attitude about ourselves and about life, all of which is just great for our overall mental health. </Text>

        <Text style={{color:"white",fontWeight:"bold",marginLeft:10,marginTop:20}}> 3. Trying new things or traveling to other countries for adventures really expands our knowledge and experience of the world. Sometimes, it takes an adventure to show us just how rich and varied the world out there is. We realize that our perspective on the world is not the only one, and that there is so much more for us to see, do and learn. Rest assured, after your first adventure you will be hungry for more! </Text>

         <Text style={{color:"white",fontWeight:"bold",marginLeft:10,marginTop:20}}> 4. Sometimes it takes an adventure to teach you just how strong, clever or brave you are. All of us have hidden strengths that we do not always know about. And, it can take an unfamiliar situation to allow those strengths to shine. After all, if we simply stick to our ordinary daily routine, never challenging ourselves to try something new, how will we ever discover anything new about ourselves? </Text>

         <Text style={{color:"white",fontWeight:"bold",marginLeft:10,marginTop:20}}> 4. Leaving our daily routine for a while to have an adventure means that we come back to our everyday life refreshed, and with a new perspective. After an adventure, our daily working day routine itself seems richer and more exciting, because our adventures have taught us to see the world in a new light. </Text>

         <TouchableOpacity onPress={this.Adventure}>
         <Text style={{fontWeight:"bold",color:"white",marginLeft:20,marginTop:20,fontFamily:"cursive"}} > 1. Adenture Campsite </Text>
         <Image source={require("../assets/skating.jpg")}style={{width:290,height:180,marginTop:10,alignSelf:"center",borderRadius:30}} />
         </TouchableOpacity>

     </ImageBackground>
      </View>
    )
  }
}