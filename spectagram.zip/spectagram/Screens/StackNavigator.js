import React from "react"
import {View,Text,Button} from "react-native"
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './HomeScreen'
import Food from "./Food"
import OutdoorGames from "./OutdoorGames"
import Adventure from "./Adventure"
import { NavigationContainer } from '@react-navigation/native';

const Stack = createStackNavigator();
export default class StackNavigator extends React.Component{
  render(){
    return(
       <NavigationContainer>
      <Stack.Navigator>
      <Stack.Screen name="MainScreen" component={HomeScreen} />
      <Stack.Screen name="Food" component={Food} />
      <Stack.Screen name="OutdoorGames" component={OutdoorGames} />
      <Stack.Screen name="Adventure" component={Adventure} />
    </Stack.Navigator>
     </NavigationContainer>
    )
  }
}