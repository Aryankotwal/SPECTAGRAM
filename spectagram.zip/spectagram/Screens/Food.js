import React from "react"
import {
ScrollView,
View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Linking,
Platform,
StatusBar,
ImageBackground,
Image} from "react-native";
import HomeScreen from "./HomeScreen";
export default class Food extends React.Component{
    healthyFood=async()=>{
    Linking.openURL("https://www.menwithkids.com/vegetarian-diet-health-benefits-and-tasty-dishes/?keyword=healthy%20vegetarian%20food%20plan&utm_source=bing&utm_medium=cpc&utm_campaign=India%20Traffic&utm_term=healthy%20vegetarian%20food%20plan&utm_content=Vegetarian%20Diet%20Health%20Benefits%20and%20Tasty%20Veggie%20Filled%20Recipes")
  }
  render(){
    return(
      <View>
      <ImageBackground source={require("../assets/Black.jpg")} style={{width: 315,height:900}}>
  <Image source={require("../assets/CameraLogo.png")}style={{width:100,height:100,marginTop:-20}}/>
      <Text style={{fontSize:20,fontWeight:"bold",marginTop:-60,marginLeft:80,fontFamily:"cursive",color:"white"}}> Food Dietitian </Text>
      <Image source={require("../assets/image_2.jpg")}style={{width:290,height:180,marginTop:30,alignSelf:"center",borderRadius:30}} />
      <Text style={{color:"white",fontWeight:"bold",marginTop:20,marginLeft:20}}> Key Facts </Text>

      <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 1. A healthy diet helps to protect against malnutrition in all its forms, as well as noncommunicable diseases (NCDs), including diabetes, heart disease, stroke and cancer. </Text>
      <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 2. Unhealthy diet and lack of physical activity are leading global risks to health. </Text>

            <Text style={{color:"white",fontWeight:"bold",marginLeft:30,marginTop:20}}> 3. Healthy dietary practices start early in life – breastfeeding fosters healthy growth and improves cognitive development, and may have longer term health benefits such as reducing the risk of becoming overweight or obese and developing NCDs later in life Click Down Below👇👇. </Text>
  <TouchableOpacity onPress={this.healthyFood}>
  <Text style={{fontWeight:"bold",color:"white",marginLeft:20,marginTop:30,fontFamily:"cursive"}}> 1. Healthy Food </Text>
  <Image source={require("../assets/HealthyFood.jpg")}style={{width:290,height:180,marginTop:10, alignSelf:"center",borderRadius:30}} />
  </TouchableOpacity>
      </ImageBackground>
      </View>
    )
  }
}