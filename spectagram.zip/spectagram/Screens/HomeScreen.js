import React from "react"
import {
View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Platform,
StatusBar,
ImageBackground,
BackgroundColor,
Image} from "react-native"
import App from "../App"
import Food from "./Food"
import OutdoorGames from "./OutdoorGames"
import Adventure from "./Adventure"
export default class HomeScreen extends React.Component{
  render(){
    return(
      <View>
<ImageBackground source={require("../assets/Black.jpg")} style={{width: 315,height:1000}}>
<Image source={require("../assets/logo.png")} style={{width: 50,height:50,marginTop:20,marginLeft:10}}/>

     <Text style={{marginTop:-45,marginLeft:60,fontSize:30,fontWeight:"bold",fontFamily:"cursive",color:"white"}}> Spectagram </Text>

    <TouchableOpacity onPress={()=>{this.props.navigation.navigate('Food')}}>
      <Image source={require("../assets/image_3.jpg")}style={{borderRadius:30,marginLeft:10,marginTop:30,width:300,height:200}}/>

      <Text style={{marginLeft:30,marginTop:10,fontWeight:"bold",color:"white"}}> Caption 1 </Text>

      <Text style={{marginTop:10,marginLeft:130,borderRadius:30,width:90,backgroundColor:"red",color:"white"}}> 🤍12K </Text>

</TouchableOpacity>

<TouchableOpacity onPress={()=>{this.props.navigation.navigate('OutdoorGames')}}>
<Image source={require("../assets/image_4.jpg")} style={{borderRadius:30,marginLeft:10,marginTop:30,width:300,height:200}}/>

<Text style={{marginLeft:30,marginTop:10,fontWeight:"bold",color:"white"}}> Caption 2 </Text>

      <Text style={{marginTop:10,marginLeft:130,borderRadius:30,width:90,backgroundColor:"red",color:"white"}}> 🤍12K </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={()=>{this.props.navigation.navigate('Adventure')}}>
      <Image source={require("../assets/image_6.jpg")}style={{borderRadius:30,marginLeft:10,marginTop:30,width:300,height:200}}/>      
      
      <Text style={{marginLeft:30,marginTop:10,fontWeight:"bold",color:"white"}}> Caption 3 </Text>

      <Text style={{marginTop:10,marginLeft:130,borderRadius:30,width:90,backgroundColor:"red",color:"white"}}> 🤍12K </Text>
      
      </TouchableOpacity>

     </ImageBackground>
      </View>
    )
  }
}