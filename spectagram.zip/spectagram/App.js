import React from "react"
import {
View,
Text,
StyleSheet,
SafeAreaView,
TouchableOpacity,
Platform,
StatusBar,
ImageBackground,
Image} from "react-native"
import HomeScreen from "./Screens/HomeScreen"
import StackNavigator from "./Screens/StackNavigator"
export default class App extends React.Component{
  render(){
    return(

      <StackNavigator/>
      
    )
  }
}